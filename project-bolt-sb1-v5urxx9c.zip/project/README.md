# Profit Calculator

A modern, responsive web application built with React and TypeScript for tracking and analyzing trading performance. This tool helps traders monitor their trades, calculate profits, and visualize performance metrics across different timeframes.

![Profit Calculator Screenshot](https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&q=80&w=1200)

## Features

- 📈 Real-time profit calculation and performance tracking
- 📅 Date-based trade organization
- 📊 Monthly performance statistics
- 💰 Automatic profit percentage calculations
- 📱 Responsive design for all devices
- 🎨 Clean and intuitive user interface

## Technology Stack

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Lucide React (for icons)

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/profit-calculator.git
```

2. Navigate to the project directory
```bash
cd profit-calculator
```

3. Install dependencies
```bash
npm install
```

4. Start the development server
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### Building for Production

To create a production build:

```bash
npm run build
```

## Usage

1. Click "Add Trade" to create a new trade entry
2. Enter the following details for each trade:
   - Date of trade
   - Coin name
   - Entry price
   - Exit price
   - Quantity
3. The application automatically calculates:
   - Profit/Loss amount
   - Profit/Loss percentage
   - Monthly statistics
   - Overall performance metrics

## Project Structure

```
src/
├── components/         # React components
├── types/             # TypeScript interfaces
├── utils/             # Utility functions
├── App.tsx            # Main application component
└── main.tsx          # Application entry point
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Icons provided by [Lucide](https://lucide.dev/)
- Styling powered by [Tailwind CSS](https://tailwindcss.com/)