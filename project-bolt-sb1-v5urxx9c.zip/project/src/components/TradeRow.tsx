import React from 'react';
import { Trash2 } from 'lucide-react';
import { Trade } from '../types/trading';
import { DatePicker } from './DatePicker';

interface TradeRowProps {
  trade: Trade;
  onDelete: (id: string) => void;
  onUpdate: (id: string, field: keyof Trade, value: any) => void;
}

export function TradeRow({ trade, onDelete, onUpdate }: TradeRowProps) {
  return (
    <div className="grid grid-cols-7 gap-4 items-center mb-4">
      <DatePicker
        date={trade.date}
        onChange={(value) => onUpdate(trade.id, 'date', value)}
      />
      <input
        type="text"
        value={trade.coinName}
        onChange={(e) => onUpdate(trade.id, 'coinName', e.target.value)}
        className="bg-white border border-gray-300 rounded px-3 py-2"
        placeholder="BTC"
      />
      <input
        type="number"
        value={trade.entryPrice}
        onChange={(e) => onUpdate(trade.id, 'entryPrice', parseFloat(e.target.value))}
        className="bg-white border border-gray-300 rounded px-3 py-2"
        placeholder="Entry Price"
      />
      <input
        type="number"
        value={trade.exitPrice}
        onChange={(e) => onUpdate(trade.id, 'exitPrice', parseFloat(e.target.value))}
        className="bg-white border border-gray-300 rounded px-3 py-2"
        placeholder="Exit Price"
      />
      <input
        type="number"
        value={trade.quantity}
        onChange={(e) => onUpdate(trade.id, 'quantity', parseFloat(e.target.value))}
        className="bg-white border border-gray-300 rounded px-3 py-2"
        placeholder="Quantity"
      />
      <div className="flex items-center gap-2">
        <span className={`font-semibold ${trade.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
          ${trade.profit.toFixed(2)}
        </span>
        <span className={`${trade.profitPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
          ({trade.profitPercentage.toFixed(2)}%)
        </span>
      </div>
      <button
        onClick={() => onDelete(trade.id)}
        className="p-2 text-red-600 hover:bg-red-50 rounded-full transition-colors"
      >
        <Trash2 size={20} />
      </button>
    </div>
  );
}