import React from 'react';
import { DailySummary } from '../types/trading';
import { LineChart, Wallet, TrendingUp } from 'lucide-react';

interface SummaryProps {
  summary: DailySummary;
}

export function Summary({ summary }: SummaryProps) {
  return (
    <div className="grid grid-cols-3 gap-6 mb-8">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <LineChart className="text-blue-600" size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Trades</h3>
            <p className="text-2xl font-bold text-gray-900">{summary.totalTrades}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-green-100 rounded-full">
            <Wallet className="text-green-600" size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Profit</h3>
            <p className="text-2xl font-bold text-gray-900">
              ${summary.totalProfit.toFixed(2)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-purple-100 rounded-full">
            <TrendingUp className="text-purple-600" size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Avg. Profit %</h3>
            <p className="text-2xl font-bold text-gray-900">
              {summary.averageProfitPercentage.toFixed(2)}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}