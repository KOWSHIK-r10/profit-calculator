import React from 'react';
import { formatDate } from '../utils/dateUtils';

interface DatePickerProps {
  date: string;
  onChange: (date: string) => void;
}

export function DatePicker({ date, onChange }: DatePickerProps) {
  return (
    <input
      type="date"
      value={date}
      onChange={(e) => onChange(e.target.value)}
      className="bg-white border border-gray-300 rounded px-3 py-2"
      max={formatDate(new Date())}
    />
  );
}