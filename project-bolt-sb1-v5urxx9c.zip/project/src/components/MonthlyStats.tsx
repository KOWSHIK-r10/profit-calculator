import React from 'react';
import { MonthlyStats as MonthlyStatsType } from '../types/trading';
import { formatMonthYear } from '../utils/dateUtils';
import { TrendingUp } from 'lucide-react';

interface MonthlyStatsProps {
  stats: MonthlyStatsType[];
}

export function MonthlyStats({ stats }: MonthlyStatsProps) {
  if (stats.length === 0) return null;

  return (
    <div className="bg-white rounded-lg shadow p-6 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="text-purple-600" size={24} />
        <h2 className="text-xl font-semibold text-gray-900">Monthly Performance</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-4">Month</th>
              <th className="text-right py-3 px-4">Total Profit</th>
              <th className="text-right py-3 px-4">Profit %</th>
              <th className="text-right py-3 px-4">Trades</th>
            </tr>
          </thead>
          <tbody>
            {stats.map((stat) => (
              <tr key={stat.month} className="border-b border-gray-100">
                <td className="py-3 px-4">{formatMonthYear(stat.month)}</td>
                <td className={`text-right py-3 px-4 ${stat.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${stat.totalProfit.toFixed(2)}
                </td>
                <td className={`text-right py-3 px-4 ${stat.profitPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.profitPercentage.toFixed(2)}%
                </td>
                <td className="text-right py-3 px-4">{stat.tradeCount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}