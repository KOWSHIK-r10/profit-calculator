import React, { useState, useCallback } from 'react';
import { Plus } from 'lucide-react';
import { Trade } from './types/trading';
import { TradeRow } from './components/TradeRow';
import { Summary } from './components/Summary';
import { MonthlyStats } from './components/MonthlyStats';
import { formatDate } from './utils/dateUtils';
import { calculateMonthlyStats } from './utils/tradeCalculations';

function App() {
  const [trades, setTrades] = useState<Trade[]>([]);

  const addTrade = () => {
    const newTrade: Trade = {
      id: Date.now().toString(),
      coinName: '',
      entryPrice: 0,
      exitPrice: 0,
      quantity: 0,
      profit: 0,
      profitPercentage: 0,
      date: formatDate(new Date()),
    };
    setTrades([...trades, newTrade]);
  };

  const deleteTrade = (id: string) => {
    setTrades(trades.filter(trade => trade.id !== id));
  };

  const updateTrade = useCallback((id: string, field: keyof Trade, value: any) => {
    setTrades(prevTrades => {
      return prevTrades.map(trade => {
        if (trade.id === id) {
          const updatedTrade = { ...trade, [field]: value };
          // Recalculate profit and percentage
          const profit = (updatedTrade.exitPrice - updatedTrade.entryPrice) * updatedTrade.quantity;
          const profitPercentage = (updatedTrade.exitPrice - updatedTrade.entryPrice) / updatedTrade.entryPrice * 100;
          
          return {
            ...updatedTrade,
            profit: profit,
            profitPercentage: profitPercentage
          };
        }
        return trade;
      });
    });
  }, []);

  const calculateSummary = () => {
    const totalTrades = trades.length;
    const totalProfit = trades.reduce((sum, trade) => sum + trade.profit, 0);
    const averageProfitPercentage = trades.length > 0
      ? trades.reduce((sum, trade) => sum + trade.profitPercentage, 0) / trades.length
      : 0;

    return {
      totalTrades,
      totalProfit,
      averageProfitPercentage
    };
  };

  const monthlyStats = calculateMonthlyStats(trades);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Trading Profit Calculator</h1>
          <p className="text-gray-600">Track your trading performance and calculate profits across multiple coins</p>
        </div>

        <Summary summary={calculateSummary()} />
        <MonthlyStats stats={monthlyStats} />

        <div className="bg-white rounded-lg shadow p-6">
          <div className="mb-6 flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Trade List</h2>
            <button
              onClick={addTrade}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus size={20} />
              Add Trade
            </button>
          </div>

          <div className="grid grid-cols-7 gap-4 mb-4 font-medium text-gray-600">
            <div>Date</div>
            <div>Coin</div>
            <div>Entry Price</div>
            <div>Exit Price</div>
            <div>Quantity</div>
            <div>Profit/Loss</div>
            <div>Actions</div>
          </div>

          {trades.map(trade => (
            <TradeRow
              key={trade.id}
              trade={trade}
              onDelete={deleteTrade}
              onUpdate={updateTrade}
            />
          ))}

          {trades.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No trades yet. Click "Add Trade" to start tracking your profits.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;