import { Trade, MonthlyStats } from '../types/trading';
import { getMonthYear } from './dateUtils';

export const calculateMonthlyStats = (trades: Trade[]): MonthlyStats[] => {
  const monthlyData: { [key: string]: MonthlyStats } = {};

  trades.forEach(trade => {
    const monthYear = getMonthYear(trade.date);
    
    if (!monthlyData[monthYear]) {
      monthlyData[monthYear] = {
        month: monthYear,
        totalProfit: 0,
        profitPercentage: 0,
        tradeCount: 0
      };
    }

    monthlyData[monthYear].totalProfit += trade.profit;
    monthlyData[monthYear].tradeCount += 1;
  });

  // Calculate average profit percentage for each month
  Object.values(monthlyData).forEach(stats => {
    stats.profitPercentage = (stats.totalProfit / stats.tradeCount) || 0;
  });

  return Object.values(monthlyData).sort((a, b) => b.month.localeCompare(a.month));
};