export const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const getMonthYear = (date: string): string => {
  return date.substring(0, 7); // Returns YYYY-MM format
};

export const formatMonthYear = (monthYear: string): string => {
  const [year, month] = monthYear.split('-');
  return new Date(parseInt(year), parseInt(month) - 1).toLocaleString('default', { 
    month: 'long', 
    year: 'numeric' 
  });
};