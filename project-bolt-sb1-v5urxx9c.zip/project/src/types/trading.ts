export interface Trade {
  id: string;
  coinName: string;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  profit: number;
  profitPercentage: number;
  date: string; // ISO date string
}

export interface DailySummary {
  totalTrades: number;
  totalProfit: number;
  averageProfitPercentage: number;
}

export interface MonthlyStats {
  month: string;
  totalProfit: number;
  profitPercentage: number;
  tradeCount: number;
}